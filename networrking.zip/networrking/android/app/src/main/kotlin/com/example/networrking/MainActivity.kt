package com.example.networrking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
